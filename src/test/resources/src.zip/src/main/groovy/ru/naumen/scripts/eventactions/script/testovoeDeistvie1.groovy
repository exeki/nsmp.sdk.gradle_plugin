def sc = utils.create('serviceCall$serviceCall', ['title':'title', 'description' : 'test', 'agreement' : subject.agreement, 'service' : subject.service, 'clientOU' : subject.clientOU, 'clientEmployee' : subject.clientEmployee])


result.showMessage("Alert!", "Я создал заявку ${sc.UUID}")

