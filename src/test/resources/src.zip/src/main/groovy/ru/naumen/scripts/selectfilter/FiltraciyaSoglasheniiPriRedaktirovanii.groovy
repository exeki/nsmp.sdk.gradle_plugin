def ATTRS_FOR_UPDATE_ON_FORMS = []
if (subject == null) return ATTRS_FOR_UPDATE_ON_FORMS
return api.filtration.disableFiltration()

